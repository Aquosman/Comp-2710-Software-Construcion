#include <iostream>
#include <cmath>
using namespace std;

float calculateSD(float data[], float x);

int main()
{
	int i,j, factorial=1;
	float data[10];
	float x = x;
	cout << "Enter number of elements up to 10: ";
	cin >> x;
	cout << "Please enter " << x << " elements:";
	
	for (i = 0; i < x; ++i)
	cin >> data[i];

	cout << endl << "Standard Deviation = " << calculateSD(data,x) << "\n";

	for (i = 1; i <= x; ++i) {
		    factorial *= i;   //factorial = factorial * i;
			}

	cout << "Factorial of "<<x<<" = "<<factorial << "\n";
	return 0;
}

float calculateSD(float data[], float x)
{
	float sum = 0.0, mean, standardDeviation = 0.0;

	int i;

	for (i = 0; i < x; ++i)
	{
	     sum += data[i];
	}

	mean = sum/x;

	for (i= 0; i < x; ++i)
	     standardDeviation += pow(data[i] - mean, 2);

	return sqrt(standardDeviation / x);
}


